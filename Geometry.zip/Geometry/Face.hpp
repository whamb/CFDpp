#ifndef FACE_h
#define FACE_h

#include <assert.h>
#include <array>

#include <Geometry.hpp>
#include <Node.hpp>
#include "Types.hpp"

class Face : public Geometry
{
public:
    
Face() = delete;
Face(const FaceID id, const NodeID nodeId) : Geometry(id), m_nodeId(nodeId){
    assert(isValid() && "Invalid Face \n");
}

bool isValid() const {
    return (m_nodeId >= 0);}

friend std::ostream& operator<<(std::ostream& os, Face& face){
    os << "Face id =  " << face.getId() << ": Node Id = " << face.m_nodeId <<  "\n";
    return os;
}

void addCell(const CellID cellId);

private:

NodeID m_nodeId;
std::array<CellID,2> m_cellIds {-1,-1};
};

#endif // face_h