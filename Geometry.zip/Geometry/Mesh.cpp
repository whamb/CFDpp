#include <iterator>
#include <vector>
#include <math.h>

#include "Cell.hpp"
#include "Face.hpp"
#include "Mesh.hpp"
#include "Node.hpp"
#include "Types.hpp"

Mesh::Mesh(const double lowerBound, const double upperBound, const double dx){
    assert(dx > 0 && "dx has to be positive");
    assert(dx <= upperBound-lowerBound && "dx has to be smaller than domain size");

    double x = lowerBound;
    while(x <= upperBound){   
        addNode(x);
        x += dx;
    }    
    if (x < upperBound + dx){
        addNode(upperBound);
    }

    for(const auto& node : m_nodes){
        addFace(*node);
    }

    for(FaceID i=0; i<m_faces.size()-1; ++i){
        addCell(*m_faces[i], *m_faces[i+1]);
    }
}

void Mesh::addNode(const double x)
{   
    m_nodes.push_back(std::make_unique<Node>(m_nodes.size(),x));
}

void Mesh::addFace(const Node& node)
{   
    m_faces.push_back(std::make_unique<Face>(m_faces.size(),node.getId()));
    m_faceCenter.push_back(node.getX());
    m_faceArea.push_back(1.0);
    m_faceNormal.push_back(1.0);
}

void Mesh::addCell(Face& f1, Face& f2){
    m_cells.push_back(std::make_unique<Cell>(m_cells.size(),f1.getId(),f2.getId()));
    m_cellCenter.push_back(0.5*(m_faceCenter[f1.getId()] - m_faceCenter[f2.getId()]));
    m_cellVolume.push_back(std::abs(m_faceCenter[f1.getId()] - m_faceCenter[f2.getId()]));

}


